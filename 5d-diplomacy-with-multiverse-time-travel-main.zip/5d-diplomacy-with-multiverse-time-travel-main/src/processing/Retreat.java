package processing;

public class Retreat extends Order {

}
