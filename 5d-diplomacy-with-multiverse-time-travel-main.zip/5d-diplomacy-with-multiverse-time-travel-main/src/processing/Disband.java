package processing;

public class Disband extends Retreat {
}
